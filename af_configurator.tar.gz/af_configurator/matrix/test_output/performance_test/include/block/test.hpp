/*
 * Copyright (C) 2025 Hirain Technologies - All Rights Reserved
 *
 */

#ifndef TEST_HPP_
#define TEST_HPP_

#include <memory>

#include "af/block/compute_block.hpp"
#include "agv_interfaces/msg/error_code_enum.hpp"
#include "agv_interfaces/msg/result_string.hpp"
#include "agv_interfaces/msg/task_data.hpp"
#include "agv_interfaces/msg/task_info_struct.hpp"
#include "agv_interfaces/msg/task_list_array.hpp"

using af::block::ComputeBlock;

class test : public ComputeBlock<agv_interfaces::msg::ErrorCodeEnum, agv_interfaces::msg::ResultString, agv_interfaces::msg::TaskData, agv_interfaces::msg::TaskInfoStruct, agv_interfaces::msg::TaskListArray>
{
public:
  bool on_init(const af::block::CustomerConfig & config) override;
  bool on_message(
    const std::shared_ptr<const agv_interfaces::msg::ErrorCodeEnum> & msg0,
    const std::shared_ptr<const agv_interfaces::msg::ResultString> & msg1,
    const std::shared_ptr<const agv_interfaces::msg::TaskData> & msg2,
    const std::shared_ptr<const agv_interfaces::msg::TaskInfoStruct> & msg3,
    const std::shared_ptr<const agv_interfaces::msg::TaskListArray> & msg4) override;
  void on_shutdown() override;
};

#endif  // TEST_HPP_
