/*
 * Copyright (C) 2025 Hirain Technologies - All Rights Reserved
 *
 */

#include "test.hpp"
 
bool test::on_init(const af::block::CustomerConfig &)
{
  // init
  AF_INFO(node()->get_logger()) << "ErrorCodeEnum: " << sizeof(agv_interfaces::msg::ErrorCodeEnum);
  AF_INFO(node()->get_logger()) << "ResultString: " << sizeof(agv_interfaces::msg::ResultString);
  AF_INFO(node()->get_logger()) << "TaskData: " << sizeof(agv_interfaces::msg::TaskData);
  AF_INFO(node()->get_logger()) << "TaskInfoStruct: " << sizeof(agv_interfaces::msg::TaskInfoStruct);
  AF_INFO(node()->get_logger()) << "TaskListArray: " << sizeof(agv_interfaces::msg::TaskListArray);
  return true;
}

bool test::on_message(
  const std::shared_ptr<const agv_interfaces::msg::ErrorCodeEnum> & msg0,
  const std::shared_ptr<const agv_interfaces::msg::ResultString> & msg1,
  const std::shared_ptr<const agv_interfaces::msg::TaskData> & msg2,
  const std::shared_ptr<const agv_interfaces::msg::TaskInfoStruct> & msg3,
  const std::shared_ptr<const agv_interfaces::msg::TaskListArray> & msg4)
{
  return true;
}

void test::on_shutdown()
{
  // shutdown
}

AF_REGISTER_BLOCK(test)
