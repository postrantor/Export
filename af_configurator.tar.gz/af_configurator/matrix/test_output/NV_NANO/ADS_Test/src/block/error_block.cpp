/*
 * Copyright (C) 2025 Hirain Technologies - All Rights Reserved
 *
 */

#include "error_block.hpp"
 
bool Error_Block::on_init(const af::block::CustomerConfig &)
{
  // init
  return true;
}

bool Error_Block::on_message(
  const std::shared_ptr<const agv_interfaces::msg::ErrorCodeEnum> & msg)
{
  return true;
}

void Error_Block::on_shutdown()
{
  // shutdown
}

AF_REGISTER_BLOCK(Error_Block)
