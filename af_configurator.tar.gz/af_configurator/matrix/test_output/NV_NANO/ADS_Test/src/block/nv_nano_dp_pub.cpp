/*
 * Copyright (C) 2025 Hirain Technologies - All Rights Reserved
 *
 */

#include "nv_nano_dp_pub.hpp"
 
bool NV_NANO_DP_Pub::on_init(const af::block::CustomerConfig &)
{
  // init
  const auto & output_topics = get_output_topics();

  auto context_domain_0 = std::make_shared<rclcpp::Context>();
  rclcpp::InitOptions options_domain_0;
  options_domain_0.auto_initialize_logging(false).set_domain_id(0);
  context_domain_0->init(0, nullptr, options_domain_0);
  node_domain_0_ = rclcpp::Node::make_shared("node_domain_0_period_task", rclcpp::NodeOptions{}.context(context_domain_0));


  publisher_Task_Topic_ = node_domain_0_->create_publisher<agv_interfaces::msg::TaskInfoStruct>(output_topics[0].name, output_topics[0].qos);
  publisher_Error_Topic_ = node_domain_0_->create_publisher<agv_interfaces::msg::ErrorCodeEnum>(output_topics[1].name, output_topics[1].qos);
  publisher_ExecuteResult_Topic_ = node_domain_0_->create_publisher<agv_interfaces::msg::ResultString>(output_topics[2].name, output_topics[2].qos);
  return true;
}

bool NV_NANO_DP_Pub::on_timer()
{
  // timer task
  return true;
}

void NV_NANO_DP_Pub::on_shutdown()
{
  // shutdown
}

AF_REGISTER_BLOCK(NV_NANO_DP_Pub)
