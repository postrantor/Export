/*
 * Copyright (C) 2025 Hirain Technologies - All Rights Reserved
 *
 */

#include <framework/Application.h>

class MainApplication : public hirain::Application {
 public:
  void onCreate() override {}
  void onStart() override {}
  void onStop() override {}
};

APPLICATION_ENTRY(MainApplication);
