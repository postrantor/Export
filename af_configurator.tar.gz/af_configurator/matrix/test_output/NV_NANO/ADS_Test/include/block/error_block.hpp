/*
 * Copyright (C) 2025 Hirain Technologies - All Rights Reserved
 *
 */

#ifndef ERROR_BLOCK_HPP_
#define ERROR_BLOCK_HPP_

#include <memory>

#include "af/block/compute_block.hpp"
#include "agv_interfaces/msg/error_code_enum.hpp"

using af::block::ComputeBlock;

class Error_Block : public ComputeBlock<agv_interfaces::msg::ErrorCodeEnum>
{
public:
  bool on_init(const af::block::CustomerConfig & config) override;
  bool on_message(
    const std::shared_ptr<const agv_interfaces::msg::ErrorCodeEnum> & msg) override;
  void on_shutdown() override;
};

#endif  // ERROR_BLOCK_HPP_
