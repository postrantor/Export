/*
 * Copyright (C) 2025 Hirain Technologies - All Rights Reserved
 *
 */

#ifndef NV_NANO_DP_PUB_HPP_
#define NV_NANO_DP_PUB_HPP_

#include "af/block/timer_block.hpp"
#include "rclcpp/rclcpp.hpp"
#include "agv_interfaces/msg/task_info_struct.hpp"
#include "agv_interfaces/msg/error_code_enum.hpp"
#include "agv_interfaces/msg/result_string.hpp"

using af::block::TimerBlock;

class NV_NANO_DP_Pub : public TimerBlock
{
public:
  bool on_init(const af::block::CustomerConfig & config) override;
  bool on_timer() override;
  void on_shutdown() override;

private:
  rclcpp::Node::SharedPtr node_domain_0_;
  rclcpp::Publisher<agv_interfaces::msg::TaskInfoStruct>::SharedPtr publisher_Task_Topic_;
  rclcpp::Publisher<agv_interfaces::msg::ErrorCodeEnum>::SharedPtr publisher_Error_Topic_;
  rclcpp::Publisher<agv_interfaces::msg::ResultString>::SharedPtr publisher_ExecuteResult_Topic_;
};

#endif  // NV_NANO_DP_PUB_HPP_
