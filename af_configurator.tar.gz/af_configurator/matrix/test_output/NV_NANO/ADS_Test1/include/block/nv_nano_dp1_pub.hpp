/*
 * Copyright (C) 2025 Hirain Technologies - All Rights Reserved
 *
 */

#ifndef NV_NANO_DP1_PUB_HPP_
#define NV_NANO_DP1_PUB_HPP_

#include "af/block/timer_block.hpp"
#include "rclcpp/rclcpp.hpp"
#include "agv_interfaces/msg/task_list_array.hpp"
#include "agv_interfaces/msg/task_data.hpp"

using af::block::TimerBlock;

class NV_NANO_DP1_Pub : public TimerBlock
{
public:
  bool on_init(const af::block::CustomerConfig & config) override;
  bool on_timer() override;
  void on_shutdown() override;

private:
  rclcpp::Node::SharedPtr node_domain_None_;
  rclcpp::Publisher<agv_interfaces::msg::TaskListArray>::SharedPtr publisher_TaskList_Topic_;
  rclcpp::Publisher<agv_interfaces::msg::TaskData>::SharedPtr publisher_TaskData_Topic_;
};

#endif  // NV_NANO_DP1_PUB_HPP_
