/*
 * Copyright (C) 2025 Hirain Technologies - All Rights Reserved
 *
 */

#include "nv_nano_dp1_pub.hpp"
 
bool NV_NANO_DP1_Pub::on_init(const af::block::CustomerConfig &)
{
  // init
  const auto & output_topics = get_output_topics();

  auto context_domain_None = std::make_shared<rclcpp::Context>();
  rclcpp::InitOptions options_domain_None;
  options_domain_None.auto_initialize_logging(false).set_domain_id(None);
  context_domain_None->init(0, nullptr, options_domain_None);
  node_domain_None_ = rclcpp::Node::make_shared("node_domain_None_period_task", rclcpp::NodeOptions{}.context(context_domain_None));


  publisher_TaskList_Topic_ = node_domain_None_->create_publisher<agv_interfaces::msg::TaskListArray>(output_topics[0].name, output_topics[0].qos);
  publisher_TaskData_Topic_ = node_domain_None_->create_publisher<agv_interfaces::msg::TaskData>(output_topics[1].name, output_topics[1].qos);
  return true;
}

bool NV_NANO_DP1_Pub::on_timer()
{
  // timer task
  return true;
}

void NV_NANO_DP1_Pub::on_shutdown()
{
  // shutdown
}

AF_REGISTER_BLOCK(NV_NANO_DP1_Pub)
